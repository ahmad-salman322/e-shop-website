import java.util.HashMap;
import java.util.SplittableRandom;

public class Cart {
    // private User owner;
    protected   HashMap<Product, Integer> cart;
    private int totalPrice;
    private String inTheCart;

    public Cart() {
        this.totalPrice = 0;
        cart = new HashMap<>();
    }

    public void addToTheCart(Product product, int quantity) {
        cart.put(product, quantity);
    }

    public void updateQuantity(Product product, int quantity) {
        addToTheCart(product, quantity);
    }

    public void remooveProduct(int quantityRemove, Product product) {
        // while (quantityRemove < 1)
        //   System.out.println("Error");
//        if (quantityRemove < 1) {
//            System.out.println("Error");
//        }
//       else {
        cart.remove(product, quantityRemove);
        //      }
    }

    /// //////////
    public int getTotalPrice() {
        int sum = 0;
        cart.forEach((product, quantity) -> {
            this.totalPrice += quantity * product.getPrice();
        });
        sum = this.totalPrice;
        this.totalPrice = 0;
        return sum;
    }

    public String toString() {
        this.inTheCart = "";
        cart.forEach((product, quantity) -> {
            this.inTheCart += product.toString() + "\nQuantity: " + quantity + "\nPrice this: " + (quantity * product.getPrice()) + "\n\n";
        });
        return this.inTheCart + "\nTotal price: " + getTotalPrice() + "\n";
    }

    public boolean isEmpty() {
        return cart.size() == 0;
    }

    public void clearCart() {
        cart.clear();
        ;
    }
}
/*
updateQuantity(Product p, int newQuantity)
يعدّل عدد القطع لمنتج معين.


clearCart()
يمسح كل المنتجات من السلة (بعد ما يتم الطلب).

toString()
يعرض محتويات السلة بشكل مرتب.*/


/*import java.util.HashMap;
import java.util.SplittableRandom;

public class Cart {
    // private User owner;
    HashMap<Integer, Product> cart;
    private int totalPrice;
    private String inTheCart;

    public Cart() {
        this.totalPrice = 0;
        cart = new HashMap<>();
    }

    public void addToTheCart(int quantity, Product product) {
        cart.put(quantity, product);
    }

    public void updateQuantity(int Quantity, Product product) {
        addToTheCart(Quantity, product);
    }

    public void remooveProduct(int quantityRemove, Product product) {
        // while (quantityRemove < 1)
        //   System.out.println("Error");
//        if (quantityRemove < 1) {
//            System.out.println("Error");
//        }
//       else {
            cart.remove(product,quantityRemove);
  //      }
    }
/// //////////
    public int getTotalPrice() {
        int sum = 0;
        cart.forEach((quantity, product) -> {
            this.totalPrice += quantity * product.getPrice();
        });
       sum = this.totalPrice;
       this.totalPrice = 0;
       return sum;
    }

    public String toString() {
        this.inTheCart = "";
        cart.forEach((quantity, product) -> {
            this.inTheCart += product.toString() + "\nQuantity: " + quantity + "\nPrice this: " + (quantity * product.getPrice()) + "\n\n";
        });
        return this.inTheCart + "\nTotal price: " + getTotalPrice() + "\n";
    }

    public boolean isEmpty() {
        return cart.size() == 0;
    }

    public void clearCart() {
        cart.clear();
        ;
    }
}
/*
updateQuantity(Product p, int newQuantity)
يعدّل عدد القطع لمنتج معين.


clearCart()
يمسح كل المنتجات من السلة (بعد ما يتم الطلب).

toString()
يعرض محتويات السلة بشكل مرتب.*/