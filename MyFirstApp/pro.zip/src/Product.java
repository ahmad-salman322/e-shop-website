public class Product {
    private int serialNumber;
    private String nameOfProduct;
    private int price;
    private int stock;
    private String description;

    // new product
    public Product(int serialNumber, String nameOfProduct, int price, String description) {
        this.serialNumber = serialNumber;
        this.nameOfProduct = nameOfProduct;
        this.price = price;
        this.description = description;
    }

    public String toString() {
        return "Serial Number:" + this.serialNumber +
                "\nName Of Product:" + this.nameOfProduct +
                "\nDescription: " + this.description;
    }

    public int getSerialNumber() {
        return serialNumber;
    }
    public void setSerialNumber(int serialNumber) {
        this.serialNumber = serialNumber;
    }

    public String getNameOfProduct() {
        return nameOfProduct;
    }
    public void setNameOfProduct(String nameOfProduct) {
        this.nameOfProduct = nameOfProduct;
    }

    public int getPrice() {
        return price;
    }
    public void setPrice(int price) {
        this.price = price;
    }

    public int getStock() {
        return stock;
    }
    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getDescription() {
        return description;
    }
    public void setDescription(String description) {
        this.description = description;
    }



}
